<?php
    /*
    * Importar planilla
    - Verificar si la cédula se encuentra como usuario, seguidamente verificar si cargó el CV
    - Emitir un mensaje, de que se intentó cargar un postulante sin que cuente con el CV cargado.
    - Agregar una Auditoria -> intento de carga de vacancia con los errores.
    */

    header('Content-Type: application/json');
    include("include/dbcommon.php");

    //if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $fileData = json_decode($_POST['fileData'], true);

        if (!$fileData) {
            echo json_encode([
                'success' => false, 
                'message' => 'No se recibió ningún dato.'
            ]);
            exit;
        }

        
        // Conectar a la base de datos PostgreSQL
        /*$conn = pg_connect("host=192.168.70.170 dbname=eportal user=franciscocuevas password=3cR561G4MkgnZ6lPy6pm");
        if (!$conn) {
            echo json_encode([
                'success' => false, 
                'message' => 'Error al conectar con la base de datos.'
            ]);
            exit;
        }*/
        
        
        // Ejemplo: iterar por las filas
        $result = [];
        foreach ($fileData as $index => $row) {
            // Realiza validaciones o inserciones en base de datos
            //$result[] = "Fila $index procesada: " . implode(', ', $row);

            // Saltear encabezados si la primera fila contiene nombres de columnas
            if ($index === 0) {
                continue; // O usa `continue` si quieres omitirla
            }

            // Validar cada campo
            $levelType = isset($row[0]) ? trim($row[0]) : null;
            $code = isset($row[1]) ? trim($row[1]) : null;
            $catalogType = isset($row[2]) ? trim($row[2]) : null;
            $name = isset($row[3]) ? trim($row[3]) : null;
            $description = isset($row[4]) ? trim($row[4]) : null;
            $sourceLink = isset($row[5]) ? trim($row[5]) : null;

            // Validar campos obligatorios
            if (empty($levelType) || empty($code) || empty($catalogType) || empty($name) || empty($description) || empty($sourceLink)) {
                $result[] = "Fila $index: Error - Hay campos vacíos.";
                continue; // Pasar a la siguiente fila
            }

            // Realiza validaciones adicionales
            //if (!is_numeric($documento)) {
                //$result[] = "Fila $index: Error - El documento debe ser numérico.";
                //continue;
            //}

            // Ejemplo: inserción (asumiendo que tienes una conexión a la base de datos)
            // $stmt = $db->prepare("INSERT INTO empleados (nropatronal, documento, nombre, apellido) VALUES (?, ?, ?, ?)");
            // $stmt->execute([$nropatronal, $documento, $nombre, $apellido]);

            
            // Insertar en base de datos o continuar con la lógica
            $result[] = "***Fila $index procesada correctamente: $levelType, $code, $catalogType, $name, $description, $sourceLink";
            
        }//end foreach

        echo json_encode([
            'success' => true, 
            'message' => 'Datos procesados correctamente***.', 
            'data' => $result
        ]);
    //} else {
        //echo json_encode([
            //'success' => false, 
            //'message' => 'Método no soportado.'
        //]);
    //}

?>